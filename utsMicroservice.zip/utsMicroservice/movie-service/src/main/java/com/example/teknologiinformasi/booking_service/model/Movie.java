package com.example.teknologiinformasi.booking_service.model;

import jakarta.persistence.*;

@Entity
@Table(name = "movies")
public class Movie {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    private String genre;
    private Double rating;

    public Movie() {}

    public Movie(String title, String genre, Double rating) {
        this.title = title;
        this.genre = genre;
        this.rating = rating;
    }

    // Getters and Setters
    public Long getId() { return id; }

    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }

    public void setTitle(String title) { this.title = title; }

    public String getGenre() { return genre; }

    public void setGenre(String genre) { this.genre = genre; }

    public Double getRating() { return rating; }

    public void setRating(Double rating) { this.rating = rating; }
}
